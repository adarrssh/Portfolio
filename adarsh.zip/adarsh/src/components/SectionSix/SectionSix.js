import React from 'react'

const SectionSix = () => {
  return (
    <div className='flex justify-center items-center h-10'>
    <div className='text-center'>
       <p className='text-gray-400'>
      {`</> & Crafted with 💛 by Shrihari`}
      </p>
    </div>
  </div>
  )
}

export default SectionSix;
