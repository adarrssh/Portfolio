import { Flex } from '@chakra-ui/react'
import React from 'react'

const WhiteSpace = () => {
  return (
    <Flex w={'100%'} h={'70px'} >
      
    </Flex>
  )
}

export default WhiteSpace
